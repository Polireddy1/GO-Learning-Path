package main

import (
	"context"
	"fmt"
	"log"

	"github.com/aws/aws-lambda-go/lambda"
)

// ECRDetail defines the structure for the image tag details in the ECR event.
type ECRDetail struct {
	RepositoryName string   `json:"repositoryName"`
	ImageTags      []string `json:"imageTags"`
}

// ECREvent defines the structure of the ECR event payload.
type ECREvent struct {
	Detail ECRDetail `json:"detail"`
}

// Handler function to process the ECR event.
func handler(ctx context.Context, event ECREvent) error {
	// Check if image tags are present in the event detail.
	if len(event.Detail.ImageTags) == 0 {
		return fmt.Errorf("no image tags found in event detail")
	}

	// Extract the first image tag from the list.
	imageTag := event.Detail.ImageTags[0]
	log.Printf("Received image tag: %s", imageTag)
	log.Printf("Repository name: %s", event.Detail.RepositoryName)

	// Further processing with the image tag can be done here.

	return nil
}

func main() {
	// Start the Lambda function.
	lambda.Start(handler)
}
